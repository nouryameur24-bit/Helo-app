/**
 * lib/anthropic.ts — Hēlo AI assistant via Supabase Edge Function
 *
 * All Anthropic API calls are proxied through the `chat` edge function so
 * that the API key never leaves the server.
 * Deploy: supabase functions deploy chat --no-verify-jwt
 * Set secret: supabase secrets set ANTHROPIC_API_KEY=sk-ant-…
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { logError } from '@/lib/logger';

import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

const CHAT_HISTORY_KEY = '@helo_chat_history';
const MAX_HISTORY = 20;

// ─── History persistence ──────────────────────────────────────────────────────

export async function loadChatHistory(): Promise<ChatMessage[]> {
  try {
    const raw = await AsyncStorage.getItem(CHAT_HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as ChatMessage[];
  } catch (err) {
    logError('anthropic.loadChatHistory', err);
    return [];
  }
}

export async function saveChatHistory(messages: ChatMessage[]): Promise<void> {
  try {
    const trimmed = messages.slice(-MAX_HISTORY);
    await AsyncStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(trimmed));
  } catch (err) {
    // Non-critical — history may be lost; conversation still works
    logError('anthropic.saveChatHistory', err, { count: messages.length });
  }
}

export async function clearChatHistory(): Promise<void> {
  try {
    await AsyncStorage.removeItem(CHAT_HISTORY_KEY);
  } catch (err) {
    // Non-critical — stale history will be overwritten on the next session
    logError('anthropic.clearChatHistory', err);
  }
}

// ─── System prompt ────────────────────────────────────────────────────────────

async function buildSystemPrompt(): Promise<string> {
  const trimesterRaw = await AsyncStorage.getItem('@helo_last_trimester').catch((err) => {
    logError('anthropic.buildSystemPrompt.readTrimester', err);
    return null;
  });
  const trimester = trimesterRaw ?? '?';
  const trimesterLabel =
    trimester === '1' ? '1er trimestre'
    : trimester === '2' ? '2ème trimestre'
    : trimester === '3' ? '3ème trimestre'
    : 'trimestre inconnu';

  return `RÈGLES ABSOLUES — À RESPECTER SANS EXCEPTION :

1. Tu n'es PAS un médecin. Tu as INTERDICTION FORMELLE de poser un diagnostic médical.

2. URGENCE — Si l'utilisatrice mentionne : douleur abdominale, saignement, contractions, perte de liquide, baisse de mouvements du bébé, fièvre forte, vomissements répétés, maux de tête sévères, troubles de la vue — ta SEULE réponse possible est :

"⚠️ Ce que vous décrivez peut nécessiter une consultation urgente. Contactez immédiatement le 15 (SAMU) ou rendez-vous à la maternité la plus proche. Ne tardez pas."

3. Pour les questions produits/ingrédients : commence TOUJOURS par "Selon les données disponibles du CRAT/ANSM/EFSA…" et cite la source.

4. Termine CHAQUE réponse par : "Pour toute décision concernant votre grossesse, consultez votre médecin ou sage-femme."

5. Tu ne donnes JAMAIS de posologie, JAMAIS de dosage exact, JAMAIS d'avis sur l'arrêt ou la prise d'un traitement.

---

Tu es l'assistante santé de Hēlo, une application française dédiée aux femmes enceintes. L'utilisatrice est actuellement au ${trimesterLabel}.

RÈGLES COMPLÉMENTAIRES :
- Tu réponds UNIQUEMENT sur les sujets liés à la grossesse : alimentation, cosmétiques, médicaments, compléments alimentaires, bien-être, hygiène de vie.
- Si la question est hors sujet, réponds gentiment que tu es spécialisée dans l'accompagnement de la grossesse.
- Tu es rassurante, bienveillante, jamais alarmiste. Ton ton est chaleureux et professionnel.
- Tes réponses sont concises (4-8 phrases maximum), claires, et adaptées à une femme enceinte non spécialiste.
- Tu utilises le vouvoiement.
- Tu écris en français uniquement.

INGRÉDIENTS CLÉS À RISQUE :
- Rétinol / rétinoïdes : déconseillés tous trimestres (tératogènes)
- Isotrétinoïne (Roaccutane) : formellement contre-indiqué
- Acide salicylique à haute dose : déconseillé
- Alcool : aucune dose sûre établie
- Caféine : max 200 mg/jour (OMS)
- Ibuprofène / AINS : contre-indiqués à partir du 6ème mois`;
}

// ─── Medication safety pre-filter ─────────────────────────────────────────────

/**
 * High-risk medications that must NEVER receive a free-form AI answer.
 * Each entry is the canonical lowercase, accent-stripped name. The user
 * message is normalized the same way before matching with word boundaries.
 *
 * Well-documented safe medications (paracétamol, doliprane, spasfon, gaviscon,
 * smecta) are intentionally NOT in this list — Claude can answer those.
 */
const BLOCKED_MEDICATIONS = [
  'methotrexate',
  'isotretinoine',
  'roaccutane',
  'accutane',
  'warfarine',
  'coumadine',
  'lithium',
  'valproate',
  'depakine',
  'misoprostol',
  'cytotec',
  'thalidomide',
  'tretinoine',
  'finasteride',
  'propecia',
  'statine',
  'atorvastatine',
  'ibuprofene',
  'advil',
  'nurofen',
  'aspirine',
  'aspegic',
  'diclofenac',
  'voltarene',
  'ketoprofene',
  'naproxene',
] as const;

/** Strip diacritics + lowercase for accent-insensitive matching. */
function normalize(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

/** Returns the matched medication name (canonical), or null. */
export function detectBlockedMedication(userMessage: string): string | null {
  const haystack = normalize(userMessage);
  for (const med of BLOCKED_MEDICATIONS) {
    // Word boundary match — avoids matching "lithiumXX" or substrings.
    const re = new RegExp(`\\b${med}\\b`, 'i');
    if (re.test(haystack)) return med;
  }
  return null;
}

/** Pretty-cased name for display in the safe response. */
function displayMedName(med: string): string {
  return med.charAt(0).toUpperCase() + med.slice(1);
}

function buildBlockedResponse(med: string): string {
  const name = displayMedName(med);
  return `⚠️ ${name} est un médicament qui nécessite un avis médical personnalisé pendant la grossesse.

Selon le CRAT (Centre de Référence sur les Agents Tératogènes), ce médicament peut présenter des risques selon votre trimestre et votre situation personnelle.

👉 Consultez la fiche officielle : https://www.lecrat.fr
👉 Parlez-en à votre médecin ou pharmacien avant toute prise.

Pour la douleur pendant la grossesse, le paracétamol (Doliprane, Efferalgan, Dafalgan) est généralement considéré comme compatible selon le CRAT. Mais même pour le paracétamol, respectez les doses et consultez votre médecin.

Pour toute décision concernant votre grossesse, consultez votre médecin ou sage-femme.`;
}

/** Best-effort logging to Supabase; never throws. */
async function logBlockedQuery(query: string, med: string): Promise<void> {
  if (!isSupabaseConfigured) return;
  try {
    const { error } = await supabase.from('blocked_medication_queries').insert({
      query_text: query,
      medication_detected: med,
      timestamp: new Date().toISOString(),
    });
    if (error) {
      logError('anthropic.logBlockedQuery.insert', error, { medication: med });
    }
  } catch (err) {
    logError('anthropic.logBlockedQuery', err, { medication: med });
  }
}

// ─── Edge function call ───────────────────────────────────────────────────────

export async function sendMessage(
  history: ChatMessage[],
  userMessage: string,
): Promise<string> {
  // ── Medication safety pre-filter (runs BEFORE any AI call) ──
  const blockedMed = detectBlockedMedication(userMessage);
  if (blockedMed) {
    // Fire-and-forget logging — never blocks the user response
    void logBlockedQuery(userMessage, blockedMed);
    return buildBlockedResponse(blockedMed);
  }

  if (!isSupabaseConfigured) {
    return "Le service de chat n'est pas encore configuré. Veuillez contacter le support Hēlo.";
  }

  const systemPrompt = await buildSystemPrompt();

  const messages = [
    ...history.slice(-10).map((m) => ({ role: m.role, content: m.content })),
    { role: 'user' as const, content: userMessage },
  ];

  try {
    const { data, error } = await supabase.functions.invoke('chat', {
      body: { messages, system: systemPrompt },
    });

    if (error) {
      logError('anthropic.sendMessage.edgeFunction', error);
      return "Une erreur est survenue. Veuillez réessayer dans quelques instants.";
    }

    type ChatData = { content?: Array<{ text?: string }> };
    const text = (data as ChatData)?.content?.[0]?.text ?? '';
    if (!text) return "Désolée, je n'ai pas pu générer une réponse. Réessayez.";
    return text;
  } catch (e) {
    logError('anthropic.sendMessage.network', e);
    return "Impossible de joindre l'assistant. Vérifiez votre connexion internet.";
  }
}
